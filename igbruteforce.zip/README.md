# Premium

Ini Adalah Script Untuk Crack Akun Instagram, Untuk Cara Menggunakannya Bisa Lihat Di https://youtu.be/u17ZQgSs3aY

# Screenshot
![Screenshot_2022-01-28-10-27-24-66_84d3000e3f4017145260f7618db1d683](https://user-images.githubusercontent.com/65714340/151503825-35b698fe-8fe9-4cf8-a722-2ea40ab314c9.png)

# Perintah
    $ pkg update && upgrade
    $ pkg install git
    $ pkg install python
    $ pip install requests
    $ pip install futures
    $ git clone https://github.com/RozhakXD/Premium
    $ cd Premium
    $ git pull
    $ python Prem.py
# Sosial Media
    • Fb : https://free.facebook.com/rozhak.xyz
    • Ig : https://www.instagram.com/rozhak_official
    • Yt : https://www.youtube.com/rozhakid
    • Wa : https://wa.me/6283847921480
